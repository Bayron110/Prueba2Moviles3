import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_auth/firebase_auth.dart';

class LeerScreen extends StatelessWidget {
  const LeerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    if (user == null) {
      return const Scaffold(
        body: Center(child: Text("Usuario no autenticado")),
      );
    }

    DatabaseReference ref =
        FirebaseDatabase.instance.ref("gastos/${user.uid}");

    return Scaffold(
      appBar: AppBar(title: const Text("Mis gastos")),
      body: StreamBuilder(
        stream: ref.onValue,
        builder: (context, snapshot) {
          if (!snapshot.hasData ||
              snapshot.data!.snapshot.value == null) {
            return const Center(child: Text("No hay gastos registrados"));
          }

          final data =
              snapshot.data!.snapshot.value as Map<dynamic, dynamic>;

          final gastos = data.entries.map((e) {
            return {
              "id": e.key,
              "titulo": e.value["titulo"],
              "descripcion": e.value["descripcion"],
              "precio": e.value["precio"],
            };
          }).toList();

          return ListView.builder(
            itemCount: gastos.length,
            itemBuilder: (context, index) {
              final item = gastos[index];

              return ListTile(
                title: Text(item["titulo"]),
                subtitle: Text("Precio: ${item["precio"]}"),
                trailing: IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () => eliminar(item["id"]),
                ),
                onTap: () => editarWidget(
                  context,
                  item["id"],
                  item["titulo"],
                  item["descripcion"],
                  item["precio"],
                ),
              );
            },
          );
        },
      ),
    );
  }
}


Future<void> eliminar(String id) async {
  final user = FirebaseAuth.instance.currentUser;
  if (user == null) return;

  FirebaseDatabase.instance
      .ref("gastos/${user.uid}/$id")
      .remove();
}


void editarWidget(
  BuildContext context,
  String id,
  String titulo,
  String descripcion,
  String precio,
) {
  final tituloCtrl = TextEditingController(text: titulo);
  final descCtrl = TextEditingController(text: descripcion);
  final precioCtrl = TextEditingController(text: precio);

  showDialog(
    context: context,
    builder: (_) => AlertDialog(
      title: const Text("Editar gasto"),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(controller: tituloCtrl),
          TextField(controller: descCtrl),
          TextField(controller: precioCtrl),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () {
            editar(
              id,
              tituloCtrl.text,
              descCtrl.text,
              precioCtrl.text,
            );
            Navigator.pop(context);
          },
          child: const Text("Guardar"),
        ),
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text("Cancelar"),
        ),
      ],
    ),
  );
}


Future<void> editar(
  String id,
  String titulo,
  String descripcion,
  String precio,
) async {
  final user = FirebaseAuth.instance.currentUser;
  if (user == null) return;

  FirebaseDatabase.instance
      .ref("gastos/${user.uid}/$id")
      .update({
    "titulo": titulo,
    "descripcion": descripcion,
    "precio": precio,
  });
}
