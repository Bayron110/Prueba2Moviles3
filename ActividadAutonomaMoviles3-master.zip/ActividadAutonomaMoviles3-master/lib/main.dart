import 'package:app_autonomo/screens/GuardarScreen.dart';
import 'package:app_autonomo/screens/LeerScreen.dart';
import 'package:app_autonomo/screens/LoginScreen.dart';
import 'package:app_autonomo/screens/RegistroScreen.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';

Future<void> main() async {
  ///
 WidgetsFlutterBinding.ensureInitialized();
await Firebase.initializeApp(
  options: DefaultFirebaseOptions.currentPlatform,
);
runApp(const MiAplicacion());
}

///

class MiAplicacion extends StatelessWidget {
  const MiAplicacion({super.key});
   @override
  Widget build(BuildContext context) {
    return MaterialApp(
      routes: {
        
        '/login': (context) => LoginScreen(),
        '/registro': (context) => RegistroScreen(),
        '/guardar': (context) => GuardarScreen(),
        '/leer': (context) => LeerScreen(),
      },

      home: Cuerpo(),

    );
  }
}

class Cuerpo extends StatelessWidget {
  const Cuerpo({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
        body: Column(children: [

          FilledButton(
            onPressed: () => Navigator.pushNamed(context, '/registro'), 
            child: Text("Registro")),

          FilledButton(
            onPressed: () => Navigator.pushNamed(context, '/login'),
          child: Text("Login")),

          ElevatedButton(
            onPressed: ()=> Navigator.pushNamed(context, '/guardar'), 
            child: Text("Guardar")),

          OutlinedButton.icon(
            onPressed: ()=> Navigator.pushNamed(context, '/leer'), 
            label: Text("Leer")),

        ],

      ),
      
    );
  }
}
